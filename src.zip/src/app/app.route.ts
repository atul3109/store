import { Routes} from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
// import { CartComponent } from './components/cart/cart.component';
import { TableComponent } from './components/table/table.component';
import { CartComponent } from './components/cart/cart.component';

export const APP_ROUTES : Routes = [{
    path : "",
    redirectTo : "login",
    pathMatch : "full"
},
{
    path : "login",                         
    component : LoginComponent
},{
    path : "register",
    component : RegisterComponent
},
{
    path : "cart",
    component : CartComponent
},
{
    path : "carttable",
    component : TableComponent
},
{
    path : "dashboard",                         
    component : DashboardComponent
}, {
    path : "**",
    component : LoginComponent
}]