
import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { ProductService } from 'src/app/services/service';
import { IProduct } from 'src/app/product.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

 cart:IProduct[];
 id:number;

  constructor(private router: Router, private productService: ProductService) { }

  ngOnInit() {
    this.cart = this.productService.getToCart();
  }

  onDeleteItem(id){
    this.productService.deleteItem(id);
  }

  backToLogin(){
    this.router.navigate(['/login'])
  }

  onBack(){
    this.router.navigate(['/dashboard'])
  }
} 
 
