import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

validUsername: string= localStorage.getItem("email");
validPassword: string= localStorage.getItem("password");

// submitted = false;


  constructor(private router:Router) { }
  
  onRegister(){
    console.log("Login Register");
    //console.log(this.router.url);
    this.router.navigate(['/register']);
  
  }


  onLogin( f :NgForm) {
    if (this.validUsername === f.value.username && this.validPassword === f.value.password){
    this.router.navigate(['/dashboard']);
  }
  else {
    alert ("Invalid Username or Password");
  }
  }
  ngOnInit() {
  }

}
