
import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/service';

import { IProduct } from 'src/app/product.model';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

   products: IProduct[];
   price:number=10000000000000;

  constructor(private product: ProductService,private router:Router) { }

  ngOnInit() {
    this.products = this.product.getAll();

  }

onAddToCart(product){
   
    this.product.getProduct(product);
  }
  cart(){
    this.router.navigate(['/carttable'])
  }
  backToLogin(){
    this.router.navigate(['/login'])
  }
} 
 
