import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';

import { text } from '@angular/core/src/render3';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {



  registerForm: FormGroup;
  
  firstname = new FormControl('',
    [Validators.required,
    Validators.pattern('[a-zA-Z]{2,20}')]
    
  );

  lastname = new FormControl('',
    [Validators.required]
  );

  email = new FormControl('',
    [Validators.required,
    Validators.email]
  );

  password = new FormControl('',
    [Validators.required,
    Validators.minLength(8)]
  );
  contact = new FormControl('',
    [Validators.required,
      Validators.minLength(10)
   ]
  );

  constructor(private router: Router,private formbuilder:FormBuilder) {
    console.log("Register Constructor");
   
    this.registerForm=formbuilder.group({
    firstname : this.firstname,
    lastname : this.lastname,
    email : this.email,
    password : this.password,
    contact : this.contact
    })
  }
  

  onRegister() {
    localStorage.setItem("firstname", this.registerForm.value.firstname);
    
    localStorage.setItem("lastname", this.registerForm.value.lastname);

    localStorage.setItem("email", this.registerForm.value.email);

    localStorage.setItem("password", this.registerForm.value.password);

    localStorage.setItem("contact", this.registerForm.value.contact);

    this.router.navigate(['/login'])
  }
  ngOnInit() {
    console.log("Register");

  }

}
