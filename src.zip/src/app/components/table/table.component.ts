import { Component, OnInit } from '@angular/core';
import { IProduct } from 'src/app/product.model';
import { ProductService } from 'src/app/services/service';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  cart : IProduct[];
   totalPrice:number=0;

  constructor(private productService : ProductService, private router : Router) { }

  
    ngOnInit() {
        this.cart = this.productService.getToCart();
        this.totalPrice=this.productService.getTotalPrice();
      }
    
      onDeleteItem(product){
        this.productService.deleteItem(product);
        this.totalPrice=this.productService.getTotalPrice();
      }
    
      backToLogin(){
        this.router.navigate(['/login'])
      }
    
      onBack(){
        this.router.navigate(['/dashboard'])
      }
}
