import { Pipe, PipeTransform } from '@angular/core';
import { IProduct } from '../product.model';

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(products:IProduct[],cost:number): any {
    let filteredProducts:IProduct[]=[];

    for(let product of products){
      if(product.price<cost){
          filteredProducts.push(product)
      }
    }
    return filteredProducts;
  }

}
