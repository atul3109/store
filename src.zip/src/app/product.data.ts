import {IProduct} from './product.model';

export const PROD_DATA: IProduct[] = [
{id:"1", name :"Queen size bed", price : 12000 , image: "bed.jpg"},
{id:"2", name :"L-shaped Sofa", price : 21000 , image: "sofa.jpg"},

{id:"3", name :"Dining Table", price : 4500 , image: "dining.jpg"},

{id:"4", name :"French Door Refrigerator - 700Lts.", price : 37000 , image: "fridge.jpg"},

{id:"5", name :"Washing Machine", price : 16000 , image: "washing.jpg"},

{id:"6", name :"Microwave", price : 7500 , image: "oven.jpg"},


]