import {Injectable} from '@angular/core';

import { IProduct } from '../product.model';
import { PROD_DATA } from '../product.data';

@Injectable({
    providedIn:'root'
})

export class ProductService{
    cart:IProduct[]=[];
   product: IProduct[];

totalPrice:number=0;
    constructor(){
       this.product=PROD_DATA 
    }

    getAll(){
        return this.product;
    }

getProduct(product){
    this.totalPrice=this.totalPrice+product.price;
    this.cart.push(product);
}

getToCart(){
    return this.cart;
}

deleteItem(product){
    this.totalPrice=this.totalPrice-product.price;
    const id=this.cart.indexOf(product);
    this.cart.splice(id,1)
}

getTotalPrice(){
    return this.totalPrice;
}
} 
 
